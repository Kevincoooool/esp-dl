#include <stdio.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_mipi_dsi.h"
#include "esp_lcd_st7703.h"
#include "esp_ldo_regulator.h"
#include "driver/gpio.h"
#include "esp_err.h"
#include "esp_log.h"
#include "lvgl.h"
#include "lv_demos.h"
#include "ksdiy_lvgl_port.h"
#include "app_video.h"

static const char *TAG = "MIPI_TEST";

// 定义LVGL图像对象
static lv_obj_t *camera_img;
static lv_img_dsc_t camera_img_desc;

// 定义摄像头刷新任务
static void camera_task(void *arg);

void app_main(void)
{
    // 初始化摄像头，使用RGB565格式
    ESP_ERROR_CHECK(ksdiy_camera_init(KSDIY_VIDEO_FMT_RGB565));
    
    // 初始化LVGL
    ksdiy_lvgl_port_init();
    ksdiy_lvgl_lock(-1);
    
    // 获取摄像头分辨率
    uint32_t width, height;
    ESP_ERROR_CHECK(ksdiy_camera_get_resolution(&width, &height));
    ESP_LOGI(TAG, "摄像头分辨率: %ldx%ld", width, height);
    
    // 创建一个全屏容器
    lv_obj_t *cont = lv_obj_create(lv_scr_act());
    lv_obj_set_size(cont, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_pad_all(cont, 0, 0);
    lv_obj_set_style_border_width(cont, 0, 0);
    lv_obj_center(cont);
    
    // 创建图像对象
    camera_img = lv_img_create(cont);
    lv_obj_center(camera_img);
    lv_obj_set_size(camera_img, 800, 800);
    
    // 设置图像描述符
    // camera_img_desc.header.always_zero = 0;
    camera_img_desc.header.w = width;
    camera_img_desc.header.h = height;
    camera_img_desc.header.cf = LV_COLOR_FORMAT_RGB565;
    camera_img_desc.data_size = width * height * 2; // RGB565每像素2字节
    camera_img_desc.data = NULL; // 将在任务中更新
    
    // 创建摄像头刷新任务
    xTaskCreate(camera_task, "camera_task", 4096, NULL, 5, NULL);
    
    ksdiy_lvgl_unlock();
}

// 摄像头刷新任务
static void camera_task(void *arg)
{
    uint8_t *frame_buffer;
    size_t frame_size;
    uint32_t frame_format;
    
    while (1) {
        // 获取一帧图像
        esp_err_t ret = ksdiy_camera_get_frame(&frame_buffer, &frame_size, &frame_format);
        if (ret == ESP_OK) {
            // 更新图像数据
            ksdiy_lvgl_lock(-1);
            camera_img_desc.data = frame_buffer;
            lv_img_set_src(camera_img, &camera_img_desc);
            ksdiy_lvgl_unlock();
        } else {
            ESP_LOGE(TAG, "获取摄像头帧失败: %s", esp_err_to_name(ret));
        }
        
        // 延时20ms，约50fps
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}